import config from "../../cep.config";
export const ns = config.id;
export const company = config.zxp.org;
export const displayName = config.displayName;
export const version = config.version;
