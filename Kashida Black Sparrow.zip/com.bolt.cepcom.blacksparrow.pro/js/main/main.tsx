import { useEffect, useState } from "react";
import { subscribeBackgroundColor, evalTS } from "../lib/utils/bolt";
import "./main.scss";

// الطريقة الصحيحة لاستيراد الصور في Vite
import logo from "../assets/logo.png";

export const App = () => {
  const [bgColor, setBgColor] = useState("#282c34");

  useEffect(() => {
    if (window.cep) {
      subscribeBackgroundColor(setBgColor);
    }
  }, []);

  const subButtonStyle = {
    padding: "10px",
    cursor: "pointer",
    backgroundColor: "#333",
    border: "1px solid #555",
    borderRadius: "4px",
    color: "white",
    fontSize: "11px",
    flex: 1,
  };

  const mainKashidaBtnStyle = {
    padding: "14px",
    cursor: "pointer",
    border: "none",
    borderRadius: "6px",
    color: "#FFFFFF",
    fontWeight: "bold",
    fontSize: "14px",
    width: "100%",
    boxShadow: "0 4px 6px rgba(0,0,0,0.3)",
  };

  return (
    <div
      className="app"
      style={{
        backgroundColor: bgColor,
        minHeight: "100vh",
        color: "white",
        position: "relative",
      }}
    >
      {/* عرض اللوجو باستخدام الـ Import المحمي */}
      <img
        src={logo}
        alt="Logo"
        style={{
          position: "absolute",
          top: "15px",
          left: "15px",
          width: "35px",
          height: "auto",
        }}
      />

      <header
        className="app-header"
        style={{ padding: "50px 20px 20px 20px", textAlign: "center" }}
      >
        <div className="logo-container" style={{ marginBottom: "30px" }}>
          <h2
            style={{
              margin: 0,
              color: "#7756A1",
              letterSpacing: "1.5px",
              fontSize: "22px",
              fontWeight: "900",
            }}
          >
            BLACK SPARROW
          </h2>
          <span
            style={{
              fontSize: "10px",
              letterSpacing: "2px",
              opacity: 0.9,
              color: "#FFFFFF",
              display: "block",
              marginTop: "5px",
            }}
          >
            KASHIDA EDITING TOOLS
          </span>
        </div>

        <div
          className="controls"
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "10px",
            maxWidth: "240px",
            margin: "0 auto",
          }}
        >
          <button
            onClick={() => evalTS("addKashidaMogrt")}
            style={{ ...mainKashidaBtnStyle, backgroundColor: "#522D76" }}
          >
            KASHIDA IN
          </button>

          <button
            onClick={() => evalTS("addKashidaAnimOut")}
            style={{ ...mainKashidaBtnStyle, backgroundColor: "#160228" }}
          >
            KASHIDA OUT
          </button>

          <div style={{ marginTop: "20px" }}>
            <p style={{ fontSize: "11px", marginBottom: "10px", opacity: 0.7 }}>
              Alignment Direction
            </p>
            <div style={{ display: "flex", gap: "8px" }}>
              <button
                style={subButtonStyle}
                onClick={() => evalTS("setKashidaDirection", 1)}
              >
                Left
              </button>
              <button
                style={subButtonStyle}
                onClick={() => evalTS("setKashidaDirection", 2)}
              >
                Center
              </button>
              <button
                style={subButtonStyle}
                onClick={() => evalTS("setKashidaDirection", 3)}
              >
                Right
              </button>
            </div>
          </div>

          <p style={{ fontSize: "9px", marginTop: "20px", opacity: 0.4 }}>
            Select clip in timeline to control direction
          </p>
        </div>
      </header>
    </div>
  );
};