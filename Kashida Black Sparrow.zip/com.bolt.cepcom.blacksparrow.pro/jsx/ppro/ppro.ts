import { dispatchTS } from "../utils/utils";

// 1. إضافة موغراف الدخول (In Animation)
export const addKashidaMogrt = () => {
  var activeSeq = app.project.activeSequence;
  if (!activeSeq) return;

  var mogrtPath = "D:/bs-pro/assets/Kashida-Stretch Black Sparrow.mogrt"; 
  var currentTime = activeSeq.getPlayerPosition();
  var trackIndex = activeSeq.videoTracks.numTracks > 1 ? 1 : 0; 

  try {
    activeSeq.importMGT(mogrtPath, currentTime.ticks, parseInt(trackIndex.toString()), 0);
  } catch (e) { 
    alert("Import Error: " + e.toString()); 
  }
};

// 2. إضافة موغراف الخروج (Out Animation)
export const addKashidaAnimOut = () => {
  var activeSeq = app.project.activeSequence;
  if (!activeSeq) return;

  var mogrtPath = "D:/bs-pro/assets/Kashida-Stretch Black Sparrow Out.mogrt"; 
  var mogrtFile = new File(mogrtPath);
  
  if (!mogrtFile.exists) {
    alert("MOGRT Out file not found at: " + mogrtPath);
    return;
  }

  var currentTime = activeSeq.getPlayerPosition();
  var trackIndex = activeSeq.videoTracks.numTracks > 1 ? 1 : 0; 

  try {
    activeSeq.importMGT(mogrtPath, currentTime.ticks, parseInt(trackIndex.toString()), 0);
  } catch (e) {
    alert("Error adding Out-Anim: " + e.toString());
  }
};

// 3. التحكم في الاتجاه (Direction) - تعديل رسائل الخطأ للإنجليزية
export const setKashidaDirection = (val: any) => {
  var activeSeq = app.project.activeSequence;
  if (!activeSeq) return;

  var selection = activeSeq.getSelection();
  
  // الرسالة المطلوبة عند عدم اختيار لير
  if (!selection || selection.length === 0) {
    alert("Please select the layer you want to adjust first.");
    return;
  }

  var numericVal = parseFloat(val);
  var clip = selection[0];
  var found = false;

  for (var i = 0; i < clip.components.numItems; i++) {
    var comp = clip.components[i];
    
    for (var j = 0; j < comp.properties.numItems; j++) {
        var prop = comp.properties[j];
        if (prop.displayName === "Direction" || prop.name === "Direction") {
            prop.setValue(numericVal, true);
            found = true;
            break;
        }
    }
    if (found) break;
  }

  if (found) {
    activeSeq.setPlayerPosition(activeSeq.getPlayerPosition());
  } else {
    alert("Direction property not found. Make sure the Mogrt has a Direction slider.");
  }
};

// 4. السنترة (Snap to Center)
export const resetMogrtPosition = () => {
  var activeSeq = app.project.activeSequence;
  var selection = activeSeq.getSelection();
  
  if (!selection || selection.length === 0) {
    alert("Please select the layer first.");
    return;
  }

  var clip = selection[0];
  var found = false;
  
  for (var i = 0; i < clip.components.numItems; i++) {
      var comp = clip.components[i];
      var posProp = comp.properties.getByName("Position");
      if (posProp) {
         posProp.setValue([0.5, 0.5], true);
         found = true;
      }
  }
  
  if (found) {
    activeSeq.setPlayerPosition(activeSeq.getPlayerPosition());
  }
};